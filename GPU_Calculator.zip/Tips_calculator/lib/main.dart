import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GPA Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: GradePointAverageCalculator(),
    );
  }
}

class GradePointAverageCalculator extends StatefulWidget {
  @override
  _GradePointAverageCalculatorState createState() =>
      _GradePointAverageCalculatorState();
}

class _GradePointAverageCalculatorState
    extends State<GradePointAverageCalculator> {
  final TextEditingController _numSubjectsController = TextEditingController();
  final List<TextEditingController> _gradeControllers = [];
  double _gpa = 0;
  @override
  void initState() {
    super.initState();
    _numSubjectsController.addListener(_onNumSubjectsChanged);
  }

  @override
  void dispose() {
    _numSubjectsController.dispose();
    _gradeControllers.forEach((controller) => controller.dispose());
    super.dispose();
  }

  void _onNumSubjectsChanged() {
    setState(() {
      _gradeControllers.clear();
      int numSubjects = int.tryParse(_numSubjectsController.text) ?? 0;
      for (int i = 0; i < numSubjects; i++) {
        _gradeControllers.add(TextEditingController());
      }
    });
  }

  void _calculateGPA() {
    try {
      List<int> grades = _gradeControllers
          .map((controller) => int.tryParse(controller.text) ?? 0)
          .toList();
      double totalGradePoints = grades.fold(0, (prev, grade) => prev + grade);

      double gpa = totalGradePoints / grades.length;
      setState(() {
        _gpa = gpa;
      });
    } catch (e) {
      print('Error calculating GPA: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculate GPA'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _numSubjectsController,
              decoration: InputDecoration(
                labelText: 'Number of Subjects',
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            Text('Enter Grades for Each Subject:'),
            SizedBox(height: 8),
            Column(
              children: _gradeControllers.map((controller) {
                return Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: TextField(
                    controller: controller,
                    decoration: InputDecoration(labelText: 'Grade'),
                    keyboardType: TextInputType.number,
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _calculateGPA,
              child: Text('Calculate GPA'),
            ),
            SizedBox(height: 16),
            Text(
              'Your GPA is: $_gpa',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
